export type SevenVectors = Record<string, number>;

// Generic JSON object helper for stored payloads.
export type JsonObject = Record<string, unknown>;
